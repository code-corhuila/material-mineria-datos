# Logo de Corhuila
# Para usar esta carpeta SCORM en Moodle, descargue el logo oficial de:
# https://raw.githubusercontent.com/code-corhuila/material-mineria-datos/b3725d694125ab35294ddfe415a327bc1445d32c/01-week/01-session/LOGO%20CORHUILA%20BLANCO%20PNG%20(2).png
#
# Y guardelo en esta carpeta como logo-corhuila.png
# 
# O modifique la ruta en index.html para usar una URL externa.
